from scrapy import cmdline
cmdline.execute("scrapy crawl novspider".split())
